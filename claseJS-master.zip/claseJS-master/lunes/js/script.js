function alertInicial() {

  alert("Ayudenme!")

}


/*
FORMAS DE MOSTRAR EN JS


alert("ayuda!");

//En algunos navegadores un document.write podria borrar todo el contenido
document.write("aqui hay algo");
document.getElementById("ej1").innerHTML="otro algo";
console.log("Aqui abajo también podemos poner cosas");

*/


/* JavaScrip es un lenguaje de PROGRAMACION
  Los lenguajes son una lista de INSTRUCCIONES llamadas DECLARACIONES
  las DECLARACIONES son separados por punto y coma

  Declarando variables:

  var x, y, z;


  Asignando Valores:

  x = 5;
  y = 6;

  Operando Valores:

  z = x + y;

  Javascrip es debilmente tipeado o sea que reconoce el tipo de variable que le estamos dando (tiene ventajas y deventajas)

  en los numero hay que ser precisos con los puntos decimal, una cadena puede tener comillas dobles o simples

  */


  /*

    Javascript funciones

    Los PARAMETROS de una funcion son los nombre en la funciones
    Los argumentos son los valores de los parametros

    una funcion puede ocurrir en tres ocaciones

    - Cuando ocurre un evento
    - Cuando es invocada desde JS
    - Porque se llama a si misma




  function regresValor(x,y){
    var z = x+y;
    return z;
  }

  */



  // QUEDA PENDIENTE OBJETOSs


  console.log(document.URL);
